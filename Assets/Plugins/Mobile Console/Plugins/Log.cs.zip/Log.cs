﻿using System.Diagnostics;
using MobileConsole;
using UnityEngine;

public static class Log
{
    #region Log
    [Conditional("DebugLog")]
    public static void Debug(object message)
    {
        UnityEngine.Debug.Log(message);
    }

	[Conditional("DebugLog")]
	public static void DebugChannel(string channels, object message)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, message);
		UnityEngine.Debug.Log(fullMessage);
	}

	[Conditional("DebugLog")]
	public static void Debug(object message, Object context)
	{
		UnityEngine.Debug.Log(message, context);
	}

	[Conditional("DebugLog")]
	public static void DebugChannel(string channels, object message, Object context)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, message);
		UnityEngine.Debug.Log(fullMessage, context);
	}

    [Conditional("DebugLog")]
    public static void Debug(object message, Color color)
    {
        UnityEngine.Debug.Log(AddColorToMessage(message, color));
    }

	[Conditional("DebugLog")]
	public static void DebugChannel(string channels, object message, Color color)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, AddColorToMessage(message, color));
		UnityEngine.Debug.Log(fullMessage);
	}

    [Conditional("DebugLog")]
    public static void DebugFormat(string format, params object[] args)
    {
        UnityEngine.Debug.LogFormat(format, args);
    }

	[Conditional("DebugLog")]
	public static void DebugFormatChannel(string channels, string format, params object[] args)
	{
		string fullFormat = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, format);
		UnityEngine.Debug.LogFormat(fullFormat, args);
	}

	[Conditional("DebugLog")]
	public static void DebugFormat(Object context, string format, params object[] args)
	{
		UnityEngine.Debug.LogFormat(context, format, args);
	}

	[Conditional("DebugLog")]
	public static void DebugFormatChannel(string channels, Object context, string format, params object[] args)
	{
		string fullFormat = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, format);
		UnityEngine.Debug.LogFormat(context, fullFormat, args);
	}
    #endregion

    #region Warning
    [Conditional("DebugLog")]
    public static void Warning(object message)
    {
        UnityEngine.Debug.LogWarning(message);
    }

	[Conditional("DebugLog")]
	public static void WarningChannel(string channels, object message)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, message);
		UnityEngine.Debug.LogWarning(fullMessage);
	}

	[Conditional("DebugLog")]
	public static void Warning(object message, Object context)
	{
		UnityEngine.Debug.LogWarning(message, context);
	}

	[Conditional("DebugLog")]
	public static void WarningChannel(string channels, object message, Object context)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, message);
		UnityEngine.Debug.LogWarning(fullMessage, context);
	}

    [Conditional("DebugLog")]
    public static void WarningFormat(string format, params object[] args)
    {
        UnityEngine.Debug.LogWarningFormat(format, args);
    }

	[Conditional("DebugLog")]
	public static void WarningFormatChannel(string channels, string format, params object[] args)
	{
		string fullFormat = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, format);
		UnityEngine.Debug.LogWarningFormat(fullFormat, args);
	}

	[Conditional("DebugLog")]
	public static void WarningFormat(Object context, string format, params object[] args)
	{
		UnityEngine.Debug.LogWarningFormat(context, format, args);
	}

	[Conditional("DebugLog")]
	public static void WarningFormatChannel(string channels, Object context, string format, params object[] args)
	{
		string fullFormat = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, format);
		UnityEngine.Debug.LogWarningFormat(context, fullFormat, args);
	}
    #endregion

    #region Error
    [Conditional("DebugLog")]
    public static void Error(object message)
    {
        UnityEngine.Debug.LogError(message);
    }

	[Conditional("DebugLog")]
	public static void ErrorChannel(string channels, object message)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, message);
		UnityEngine.Debug.LogError(fullMessage);
	}

	[Conditional("DebugLog")]
	public static void Error(object message, Object context)
	{
		UnityEngine.Debug.LogError(message, context);
	}

	[Conditional("DebugLog")]
	public static void ErrorChannel(string channels, object message, Object context)
	{
		string fullMessage = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, message);
		UnityEngine.Debug.LogError(fullMessage, context);
	}

    [Conditional("DebugLog")]
    public static void ErrorFormat(string format, params object[] args)
    {
        UnityEngine.Debug.LogErrorFormat(format, args);
    }

	[Conditional("DebugLog")]
	public static void ErrorFormatChannel(string channels, string format, params object[] args)
	{
		string fullFormat = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, format);
		UnityEngine.Debug.LogErrorFormat(fullFormat, args);
	}

	[Conditional("DebugLog")]
	public static void ErrorFormat(Object context, string format, params object[] args)
	{
		UnityEngine.Debug.LogErrorFormat(context, format, args);
	}

	[Conditional("DebugLog")]
	public static void ErrorFormatChannel(string channels, Object context, string format, params object[] args)
	{
		string fullFormat = string.Format(LogConsoleSettings.Instance.fullChannelFormat, channels, format);
		UnityEngine.Debug.LogErrorFormat(context, fullFormat, args);
	}
    #endregion

    #region Exception
	[Conditional("DebugLog")]
	public static void Exception(System.Exception exception)
	{
		UnityEngine.Debug.LogException(exception);
	}

	[Conditional("DebugLog")]
	public static void Exception(System.Exception exception, Object context)
	{
		UnityEngine.Debug.LogException(exception, context);
	}
    #endregion


    static string AddColorToMessage(object message, Color color)
    {
        return string.Format("<color=#{0}>{1}</color>", ColorUtility.ToHtmlStringRGB(color), message);
    }
}
